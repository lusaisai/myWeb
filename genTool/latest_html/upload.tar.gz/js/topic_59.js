$( function() {

$('#list282').mouseover(function() {
	$('#topic59 img').attr('src', 'http://img.xiami.com/images/album/img93/1593/88591314675786_2.jpg');
	$('#topic59 span.listtxt').html('韩雪似乎就是和雪有缘，最好听的两首歌都带有“雪”字。她给人一种恬静温柔的感觉，歌声也很动人。');
	});
$('#list282').click(function() {
	$('#musicPlayer h3').html('飘雪');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_110215,110216,110217,110218,110219,110220,110221,110222,110223,110224,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic59 li').css('color', '#000000');
	$('#list282').css('color', '#CC0052');
	});

$('#list283').mouseover(function() {
	$('#topic59 img').attr('src', 'http://img.xiami.com/images/album/img93/1593/8858_2.jpg');
	$('#topic59 span.listtxt').html('我最喜欢的一张专辑，专辑封面一眼就让我心动了。');
	});
$('#list283').click(function() {
	$('#musicPlayer h3').html('夏·恋情');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_110205,110207,110209,110213,110206,110208,110210,110211,110212,110214,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic59 li').css('color', '#000000');
	$('#list283').css('color', '#CC0052');
	});
$('#list284').mouseover(function() {
	$('#topic59 img').attr('src', 'http://img.xiami.com/images/album/img93/1593/32959_2.jpg');
	$('#topic59 span.listtxt').html('感受一下韩雪歌声里特别的浪漫与清新吧～～～');
	});
$('#list284').click(function() {
	$('#musicPlayer h3').html('狂想的旅程');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_393376,393378,393377,393379,393380,393381,393382,393383,393384,393385,393386,393387,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic59 li').css('color', '#000000');
	$('#list284').css('color', '#CC0052');
	});
}
)
;
