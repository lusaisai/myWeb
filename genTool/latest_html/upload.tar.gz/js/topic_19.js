$( function() {

$('#list144').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/artistlogo/67/13165269535667.jpg');
	$('#topic19 span.listtxt').html('爱上宥嘉因为两首歌《我爱的人》和《你是我的眼》。');
	});
$('#list144').click(function() {
	$('#musicPlayer h3').html('宥嘉精选');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2103335,1769167647,1770182611,1769945814,1770160772,1769167648,2088669,2088663,3658234,3658231,1769250903,392311,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list144').css('color', '#CC0052');
	});

$('#list145').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img17/23517/1690341323770523.jpg');
	$('#topic19 span.listtxt').html('也许你也会因为一个人的眼色而爱上他，从而跌入深不见底的快乐。');
	});
$('#list145').click(function() {
	$('#musicPlayer h3').html('神秘嘉宾');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2088663,2088664,2088665,2088666,2088667,2088668,2088669,2088670,2088671,2088672,2088673,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list145').css('color', '#CC0052');
	});
$('#list146').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img17/23517/3582651260165183.jpg');
	$('#topic19 span.listtxt').html('《only you》其实可以唱得很好听。大家合唱《我爱的人》很让人感动。');
	});
$('#list146').click(function() {
	$('#musicPlayer h3').html('重返迷宫LIVE演唱会');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769250901,1769250902,1769250903,1769250904,1769250905,1769250906,1769250907,1769250908,1769250909,1769250910,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list146').css('color', '#CC0052');
	});
$('#list147').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img17/23517/3282691241604185.jpg');
	$('#topic19 span.listtxt').html('每一首都很好听，都是林宥嘉自己喜欢的歌。');
	});
$('#list147').click(function() {
	$('#musicPlayer h3').html('香港迷宫演唱会');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_3658231,3658232,3658233,3658234,3658235,3658236,3658237,3658238,3658239,3658240,3658241,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list147').css('color', '#CC0052');
	});
$('#list148').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img0//3510481257735307.jpg');
	$('#topic19 span.listtxt').html('《心酸》太有感觉了，让人想起少年时代的遗憾。');
	});
$('#list148').click(function() {
	$('#musicPlayer h3').html('感官/世界');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769167642,1769167643,1769167644,1769167645,1769167646,1769167647,1769167648,1769167649,1769167650,1769167651,1769167652,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list148').css('color', '#CC0052');
	});
$('#list149').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img17/23517/4386281309139851.jpg');
	$('#topic19 span.listtxt').html('啥时候能拥有美妙的生活呢？');
	});
$('#list149').click(function() {
	$('#musicPlayer h3').html('美妙生活');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1770182609,1770182610,1770182611,1770182612,1770182613,1770182614,1770182615,1770182616,1770182617,1770160772,1770182619,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list149').css('color', '#CC0052');
	});
$('#list150').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img69/7169/4180881304850342.jpg');
	$('#topic19 span.listtxt').html('感官/世界巡迴音乐会的精选。');
	});
$('#list150').click(function() {
	$('#musicPlayer h3').html('Senses Around Live Tour');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1769945812,1769945813,1769945814,1769945815,1769945816,1769945817,1769945818,1769945819,1769945820,1769945821,1769945822,1769945823,1769945824,1770189727,1770189728,1770189729,1770189730,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list150').css('color', '#CC0052');
	});
$('#list314').mouseover(function() {
	$('#topic19 img').attr('src', 'http://img.xiami.com/images/album/img17/23517/5161021340071211_2.jpg');
	$('#topic19 span.listtxt').html('听听《浪费》吧，用 一生 去爱 一个人。');
	});
$('#list314').click(function() {
	$('#musicPlayer h3').html('大小说家');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1770990303,1771093939,1771093940,1771093941,1771039797,1771093943,1771093944,1771093945,1771093946,1771093947,1771113009,1771113010,1771113011,1771113012,1771113013,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic19 li').css('color', '#000000');
	$('#list314').css('color', '#CC0052');
	});
}
)
;
