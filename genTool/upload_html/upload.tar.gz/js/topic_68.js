$( function() {

$('#list311').mouseover(function() {
	$('#topic68 img').attr('src', 'http://img.xiami.com/images/collect/184/84/7978184_1319775374_4.jpg');
	$('#topic68 span.listtxt').html('似乎经典的歌曲里总是沉淀着很多的情感，每一首歌你都能勾勒出一幅画面来。');
	});
$('#list311').click(function() {
	$('#musicPlayer h3').html('欧美金唱盘CD1');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1022372,3445584,3596943,1495938,3415337,2140338,1835292,3670152,1769385808,1769772755,1283216,1697787,2088864,3320101,1768985446,2091695,3484474,2552384,1768967981,200107,1769198365,3680711,3259639,3541673,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic68 li').css('color', '#000000');
	$('#list311').css('color', '#CC0052');
	});

$('#list312').mouseover(function() {
	$('#topic68 img').attr('src', 'http://img.xiami.com/images/collect/184/84/7978184_1319775374_4.jpg');
	$('#topic68 span.listtxt').html('似乎经典的歌曲里总是沉淀着很多的情感，每一首歌你都能勾勒出一幅画面来。');
	});
$('#list312').click(function() {
	$('#musicPlayer h3').html('欧美金唱盘CD2');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_1165240,3562578,3368520,2780617,1191413,1597349,1770153,3365845,1333467,2052317,1769517803,1769526243,3666620,1458763,3588382,1769025680,1390029,1333147,1191418,3593307,3504463,3449500,3141873,1813291,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic68 li').css('color', '#000000');
	$('#list312').css('color', '#CC0052');
	});
$('#list313').mouseover(function() {
	$('#topic68 img').attr('src', 'http://img.xiami.com/images/collect/184/84/7978184_1319775374_4.jpg');
	$('#topic68 span.listtxt').html('似乎经典的歌曲里总是沉淀着很多的情感，每一首歌你都能勾勒出一幅画面来。');
	});
$('#list313').click(function() {
	$('#musicPlayer h3').html('欧美金唱盘CD3');
	$('#musicPlayer embed').replaceWith('<embed src="http://www.xiami.com/widget/4097932_2554151,1769691657,1843271,1011884,2552559,1412106,2088073,1769176495,1014826,1769409185,1007407,1769039370,2554137,1562173,3488409,1768940408,3486203,1083760,1067647,2103991,2090657,2098516,1885942,_235_346_000000_494949_1/multiPlayer.swf" type="application/x-shockwave-flash" width="235" height="346" wmode="opaque"></embed>');
	$('#topic68 li').css('color', '#000000');
	$('#list313').css('color', '#CC0052');
	});
}
)
;
