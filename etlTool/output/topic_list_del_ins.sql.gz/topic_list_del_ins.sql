delete from stg_f_topic_w;
delete from stg_f_topic_list_w;
call topic_list_ups;
